﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CNBlogs.UWP.Tools
{
    /// <summary>
    /// 登录辅助
    /// </summary>
    class LoginTool
    {
        private string _baseHtml = "";
    }
}
