#CNBlogs.UWP#
博客园第三方客户端UWP版

--------------------------

##概述##
源码中包含PC和Mobile端两种，但是只有PC端经过了测试，Mobile端的代码并没有在Windows 10
手机上测试过。因此只有PC端的应用上传到了Windows Stroe，链接为：

作为练手项目，项目结构有点混乱，并没有使用MVVM模式开发，View和ViewModel写在了一起
（充分利用了Code Behind文件 ：)）


##PC截图##
![](https://github.com/sherlockchou86/CNBlogs.UWP/blob/master/Screenshots/PC/%E5%8D%9A%E5%AE%A2%E9%A6%96%E9%A1%B5.PNG)

![](https://github.com/sherlockchou86/CNBlogs.UWP/blob/master/Screenshots/PC/%E6%96%B0%E9%97%BB%E9%A6%96%E9%A1%B5.PNG)

![](https://github.com/sherlockchou86/CNBlogs.UWP/blob/master/Screenshots/PC/%E7%90%85%E7%90%8A%E6%A6%9C%E9%A6%96%E9%A1%B5.PNG)

![](https://github.com/sherlockchou86/CNBlogs.UWP/blob/master/Screenshots/PC/%E5%8D%9A%E5%AE%A2%E5%88%86%E4%BA%AB.PNG)

![](https://github.com/sherlockchou86/CNBlogs.UWP/blob/master/Screenshots/PC/%E5%85%B3%E7%81%AF%E6%95%88%E6%9E%9C.PNG)

![](https://github.com/sherlockchou86/CNBlogs.UWP/blob/master/Screenshots/PC/%E4%B8%AA%E4%BA%BA%E8%AF%A6%E7%BB%86%E4%B8%BB%E9%A1%B5.PNG)

![](https://github.com/sherlockchou86/CNBlogs.UWP/blob/master/Screenshots/PC/%E7%82%B9%E8%B5%9E%E6%88%90%E5%8A%9F.PNG)

更多图片请戳：[PC截图](https://github.com/sherlockchou86/CNBlogs.UWP/tree/master/Screenshots/PC)


##手机截图(模拟器)##
![](https://github.com/sherlockchou86/CNBlogs.UWP/blob/master/Screenshots/Mobile/%E5%8D%9A%E5%AE%A2%E9%A6%96%E9%A1%B5.PNG)

![](https://github.com/sherlockchou86/CNBlogs.UWP/blob/master/Screenshots/Mobile/%E6%96%B0%E9%97%BB%E9%A6%96%E9%A1%B5.PNG)

![](https://github.com/sherlockchou86/CNBlogs.UWP/blob/master/Screenshots/Mobile/%E7%90%85%E7%90%8A%E6%A6%9C%E9%A6%96%E9%A1%B5.PNG)


##说明##
详细信息查看博客：[CNBlogs](http://xiaozhi_5638.cnblogs.com)

所有源代码均遵循MIT协议。