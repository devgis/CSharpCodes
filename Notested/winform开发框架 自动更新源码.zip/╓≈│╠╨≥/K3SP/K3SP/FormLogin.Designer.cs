﻿namespace K3SP
{
    partial class FormLogin
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLogin));
            this.labelK3SP = new System.Windows.Forms.Label();
            this.labelTM = new System.Windows.Forms.Label();
            this.textBoxTM = new System.Windows.Forms.TextBox();
            this.labelXM = new System.Windows.Forms.Label();
            this.labelMM = new System.Windows.Forms.Label();
            this.textBoxMM = new System.Windows.Forms.TextBox();
            this.labelXMM = new System.Windows.Forms.Label();
            this.textBoxXMM = new System.Windows.Forms.TextBox();
            this.labelQRMM = new System.Windows.Forms.Label();
            this.textBoxQRMM = new System.Windows.Forms.TextBox();
            this.comboBoxXM = new System.Windows.Forms.ComboBox();
            this.buttonXGMM = new System.Windows.Forms.Button();
            this.button_Login = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelK3SP
            // 
            this.labelK3SP.AutoSize = true;
            this.labelK3SP.Font = new System.Drawing.Font("隶书", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelK3SP.ForeColor = System.Drawing.Color.Red;
            this.labelK3SP.Location = new System.Drawing.Point(227, 33);
            this.labelK3SP.Name = "labelK3SP";
            this.labelK3SP.Size = new System.Drawing.Size(538, 56);
            this.labelK3SP.TabIndex = 0;
            this.labelK3SP.Text = "欢迎进入K3补充程序";
            // 
            // labelTM
            // 
            this.labelTM.AutoSize = true;
            this.labelTM.Font = new System.Drawing.Font("隶书", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelTM.Location = new System.Drawing.Point(346, 135);
            this.labelTM.Name = "labelTM";
            this.labelTM.Size = new System.Drawing.Size(147, 33);
            this.labelTM.TabIndex = 0;
            this.labelTM.Text = "条码登录";
            // 
            // textBoxTM
            // 
            this.textBoxTM.Font = new System.Drawing.Font("隶书", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxTM.Location = new System.Drawing.Point(499, 135);
            this.textBoxTM.Name = "textBoxTM";
            this.textBoxTM.Size = new System.Drawing.Size(147, 35);
            this.textBoxTM.TabIndex = 1;
            // 
            // labelXM
            // 
            this.labelXM.AutoSize = true;
            this.labelXM.Font = new System.Drawing.Font("隶书", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelXM.Location = new System.Drawing.Point(346, 176);
            this.labelXM.Name = "labelXM";
            this.labelXM.Size = new System.Drawing.Size(147, 33);
            this.labelXM.TabIndex = 0;
            this.labelXM.Text = "输入姓名";
            // 
            // labelMM
            // 
            this.labelMM.AutoSize = true;
            this.labelMM.Font = new System.Drawing.Font("隶书", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelMM.Location = new System.Drawing.Point(346, 217);
            this.labelMM.Name = "labelMM";
            this.labelMM.Size = new System.Drawing.Size(147, 33);
            this.labelMM.TabIndex = 0;
            this.labelMM.Text = "输入密码";
            // 
            // textBoxMM
            // 
            this.textBoxMM.Font = new System.Drawing.Font("隶书", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxMM.Location = new System.Drawing.Point(499, 217);
            this.textBoxMM.Name = "textBoxMM";
            this.textBoxMM.Size = new System.Drawing.Size(147, 35);
            this.textBoxMM.TabIndex = 1;
            // 
            // labelXMM
            // 
            this.labelXMM.AutoSize = true;
            this.labelXMM.Font = new System.Drawing.Font("隶书", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelXMM.Location = new System.Drawing.Point(346, 320);
            this.labelXMM.Name = "labelXMM";
            this.labelXMM.Size = new System.Drawing.Size(147, 33);
            this.labelXMM.TabIndex = 0;
            this.labelXMM.Text = "输新密码";
            // 
            // textBoxXMM
            // 
            this.textBoxXMM.Font = new System.Drawing.Font("隶书", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxXMM.Location = new System.Drawing.Point(499, 320);
            this.textBoxXMM.Name = "textBoxXMM";
            this.textBoxXMM.Size = new System.Drawing.Size(147, 35);
            this.textBoxXMM.TabIndex = 1;
            // 
            // labelQRMM
            // 
            this.labelQRMM.AutoSize = true;
            this.labelQRMM.Font = new System.Drawing.Font("隶书", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelQRMM.Location = new System.Drawing.Point(346, 361);
            this.labelQRMM.Name = "labelQRMM";
            this.labelQRMM.Size = new System.Drawing.Size(147, 33);
            this.labelQRMM.TabIndex = 0;
            this.labelQRMM.Text = "确认密码";
            // 
            // textBoxQRMM
            // 
            this.textBoxQRMM.Font = new System.Drawing.Font("隶书", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxQRMM.Location = new System.Drawing.Point(499, 361);
            this.textBoxQRMM.Name = "textBoxQRMM";
            this.textBoxQRMM.Size = new System.Drawing.Size(147, 35);
            this.textBoxQRMM.TabIndex = 1;
            // 
            // comboBoxXM
            // 
            this.comboBoxXM.Font = new System.Drawing.Font("隶书", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.comboBoxXM.FormattingEnabled = true;
            this.comboBoxXM.Location = new System.Drawing.Point(499, 176);
            this.comboBoxXM.Name = "comboBoxXM";
            this.comboBoxXM.Size = new System.Drawing.Size(147, 32);
            this.comboBoxXM.TabIndex = 2;
            // 
            // buttonXGMM
            // 
            this.buttonXGMM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonXGMM.Font = new System.Drawing.Font("隶书", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonXGMM.Location = new System.Drawing.Point(346, 269);
            this.buttonXGMM.Name = "buttonXGMM";
            this.buttonXGMM.Size = new System.Drawing.Size(147, 45);
            this.buttonXGMM.TabIndex = 3;
            this.buttonXGMM.Text = "更改密码";
            this.buttonXGMM.UseVisualStyleBackColor = false;
            this.buttonXGMM.Click += new System.EventHandler(this.buttonXGMM_Click);
            // 
            // button_Login
            // 
            this.button_Login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button_Login.Font = new System.Drawing.Font("隶书", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_Login.Location = new System.Drawing.Point(499, 269);
            this.button_Login.Name = "button_Login";
            this.button_Login.Size = new System.Drawing.Size(147, 45);
            this.button_Login.TabIndex = 3;
            this.button_Login.Text = "进入程序";
            this.button_Login.UseVisualStyleBackColor = false;
            this.button_Login.Click += new System.EventHandler(this.button_Login_Click);
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(992, 566);
            this.Controls.Add(this.button_Login);
            this.Controls.Add(this.buttonXGMM);
            this.Controls.Add(this.comboBoxXM);
            this.Controls.Add(this.textBoxQRMM);
            this.Controls.Add(this.textBoxXMM);
            this.Controls.Add(this.textBoxMM);
            this.Controls.Add(this.labelQRMM);
            this.Controls.Add(this.textBoxTM);
            this.Controls.Add(this.labelXMM);
            this.Controls.Add(this.labelMM);
            this.Controls.Add(this.labelXM);
            this.Controls.Add(this.labelTM);
            this.Controls.Add(this.labelK3SP);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "登录窗口";
            this.Load += new System.EventHandler(this.FormLogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelK3SP;
        private System.Windows.Forms.Label labelTM;
        private System.Windows.Forms.TextBox textBoxTM;
        private System.Windows.Forms.Label labelXM;
        private System.Windows.Forms.Label labelMM;
        private System.Windows.Forms.TextBox textBoxMM;
        private System.Windows.Forms.Label labelXMM;
        private System.Windows.Forms.TextBox textBoxXMM;
        private System.Windows.Forms.Label labelQRMM;
        private System.Windows.Forms.TextBox textBoxQRMM;
        private System.Windows.Forms.ComboBox comboBoxXM;
        private System.Windows.Forms.Button buttonXGMM;
        private System.Windows.Forms.Button button_Login;
    }
}

